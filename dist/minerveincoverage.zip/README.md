# MinerVeinCoverage
Dyson Sphere Mod to show maximum miner speed in the UI.

# Building

Run `dotnet build` from the directory. You will need to provide the referenced DLL's and place them in the `/lib` directory before you build.